package Blaze_Demo;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import com.google.common.io.Files;

public class TravelTheWorld_Blaze_Demo
{

	public static void main(String[] args) throws Exception 
	{
		Select s;

        System.setProperty("webdriver.chrome.driver","D:\\Automation Testing\\Eclipse Backup\\Blaze_Demo\\Browser Extension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.get("https://blazedemo.com/");
		Thread.sleep(2000);

		//Dropdown 1:
		s=new Select(driver.findElement(By.xpath("//select[@name='fromPort']")));
		//step 2 : Select option
		s.selectByIndex(3);
		//s.deselectByValue("Portland");
		//s.selectByVisibleText("Portland");
		
		Thread.sleep(2000);
		//Dropdown 2:
		s=new Select(driver.findElement(By.xpath("//select[@name='toPort']")));
		s.selectByIndex(4);
		Thread.sleep(2000);
		
		//Find Flights
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		Thread.sleep(2000);
		
		
		//choose the flight
		driver.findElement(By.cssSelector("input[type='submit']")).click();		
		Thread.sleep(2000);


	}

}
