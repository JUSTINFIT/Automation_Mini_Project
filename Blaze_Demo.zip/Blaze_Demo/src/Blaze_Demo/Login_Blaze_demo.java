package Blaze_Demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Blaze_demo
{
	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver","D:\\Automation Testing\\Eclipse Backup\\Blaze_Demo\\Browser Extension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.get("https://blazedemo.com/");
		Thread.sleep(2000);
   
		//Home
		driver.findElement(By.xpath("//a[@href='home']")).click();
		Thread.sleep(2000);
		
		//Login
		driver.findElement(By.id("email")).sendKeys("cat16060808@gmail.com.com");
		Thread.sleep(1000);
		driver.findElement(By.id("password" )).sendKeys("16060808");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("button[type='submit']")).click();
	    Thread.sleep(1000);
		    
		driver.close();
		    
   }
}

